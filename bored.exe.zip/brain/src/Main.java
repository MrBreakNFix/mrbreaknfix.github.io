import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class Main {
    private static int boredLevel = 98565;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Brain.exe");
        frame.setBounds(0, 0, 420, 420);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLayout(null);

        JLabel label = new JLabel("Bored Level: " + boredLevel);
        label.setFocusable(false);
        label.setFont(new Font("plain", Font.PLAIN, 40));
        label.setBounds(0, 20, 420, 40);

        frame.add(label);
        frame.setVisible(true);

        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                boredLevel++;
                label.setText("Bored Level: " + boredLevel);
                frame.repaint();
            }
        };
        timer.scheduleAtFixedRate(task, 1000L, 1000L);
    }
}
